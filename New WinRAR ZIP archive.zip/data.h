#ifndef DATA_H
#define DATA_H

#include "spaces.h"

extern Space spaces[MAX_SPACES];
extern int numSpaces;

int loadFile(Space *spaces);
// void consoleClean();

#endif