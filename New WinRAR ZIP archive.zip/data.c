#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "spaces.h"

Space spaces[MAX_SPACES];
int numSpaces = 0;

void loadFile(Space *spaces)
{
    int index = 0;
    char line[256];
    FILE *file = fopen("spaces.csv", "r");

    if (file == NULL)
    {
        printf("Error: Could not open file spaces.csv\n");
        return;
    }

    while (fgets(line, sizeof(line), file) && index < MAX_SPACES)
    {
        char *cell;
        cell = strtok(line, ",");
        spaces[index].id = atoi(cell);

        cell = strtok(NULL, ",");
        strncpy(spaces[index].name, cell, MAX_NAME_LENGTH - 1);
        // Remove trailing newline from name
        spaces[index].name[strcspn(spaces[index].name, "\n")] = '\0';

        cell = strtok(NULL, ",");
        strncpy(spaces[index].type, cell, MAX_TYPE_LENGTH - 1);
        // Remove trailing newline from type
        spaces[index].type[strcspn(spaces[index].type, "\n")] = '\0';

        cell = strtok(NULL, ",");
        spaces[index].capacity = atoi(cell);
        index++;
    }
    fclose(file);
    printf("Loaded %d spaces from file.\n", index);

    numSpaces = index;
}